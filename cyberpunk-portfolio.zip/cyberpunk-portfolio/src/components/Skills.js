import React from 'react';

const Skills = () => {
  return (
    <section id="skills" className="my-10">
      <h2>Skills</h2>
      <ul>
        <li>Java</li>
        <li>SQL</li>
        <li>Python</li>
        <li>JavaScript</li>
        <li>HTML/CSS</li>
        <li>AngularJS</li>
        <li>C, C++</li>
      </ul>
    </section>
  );
};

export default Skills;
