import React from 'react';

const Projects = () => {
  return (
    <section id="projects" className="my-10">
      <h2>Projects</h2>
      <ul>
        <li>Brain Tumor Detection using DQN</li>
        <li>Medicare Web Application</li>
        <li>Legos Parker</li>
      </ul>
    </section>
  );
};

export default Projects;
